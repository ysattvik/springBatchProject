package com.batch.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBatchExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
