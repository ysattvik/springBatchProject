package com.batch.example.config;

import com.batch.example.model.Product;
import org.springframework.batch.item.ItemProcessor;

public class CustomItemProcessor implements ItemProcessor<Product, Product> {
    @Override
    public Product process(Product item) throws Exception {
        // transform logic here
        // Calculate discountedPrice

        try {
            System.out.println(item.getDescription());
            double discountPer = Double.parseDouble(item.getDiscount().trim());
            double origionalPrice = Double.parseDouble(item.getPrice().trim());
            double discount = (discountPer / 100.0d)*origionalPrice;
            double finalPrice = origionalPrice - discount;
            item.setDiscountedPrice(String.valueOf(finalPrice));
        } catch (NumberFormatException ex) {
            ex.printStackTrace();
        }


        return item;
    }
}
